#ifndef LibrarySumOfAngles_HPP
#define LibrarySumOfAngles_HPP

#include <iostream>
using namespace std;

class LibrarySumOfAngles
{
	private:
		//Only functions inside the class can access private class functions.

	public:
		LibrarySumOfAngles();
		double getAns(double A, double B);
		~LibrarySumOfAngles();

};
# endif
